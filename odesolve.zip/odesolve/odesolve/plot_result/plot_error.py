from math import e
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator
from tqdm import tqdm
from odesolve import solveto, euler, rk4

a = [0.00001,0.0001,0.001,0.01,0.1]
h_list = list(a)
for item in a[:-1]:
    for i in range(2,10):
        h_list.append(item*i)
h_list.sort()
def f(x,t):
    return x

euler_error =[]
rk4_error =[]

for h in tqdm(h_list):
    euler_error.append(abs(e - solveto(f, 1, 0,1, h,euler)))
    rk4_error.append(abs(e - solveto(f, 1, 0,1, h,rk4)))

print(euler_error)
print(rk4_error)

harray = np.linspace(0.00001,0.1,len(euler_error))
plt.scatter(harray, euler_error)
plt.scatter(harray, rk4_error)
plt.xticks([0,1e-5,1e-4,1e-3,1e-2,1e-1]) #设置x轴刻度
plt.yticks([1e-15,1e-13,1e-11,1e-9,1e-7,1e-5,1e-3,1e-1]) #设置y轴刻度
plt.legend(['Euler','RK4'])
plt.savefig("error.pdf")
plt.xlabel('h') #为x轴命名为“x”
plt.ylabel('plot_error') #为y轴命名为“y”
plt.show()