import numpy as np
from matplotlib import pyplot as plt
from odesolve import odesolve


def f(X,t):
    x,y = X
    dxdt = y
    dydt = -x
    return  np.array([dxdt,dydt])

x0 = 1
y0 = 0

X0 = np.array([x0,y0])
h = 0.01
t = np.linspace(0,10,1000)
Xt = odesolve(f,X0,t,h)

plt.plot(t, Xt)
plt.savefig("plot_odesolve.pdf")
plt.show ( )
