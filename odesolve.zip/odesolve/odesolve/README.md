

## What this do?

   The numerical methods to solve ordinary differential equations (ODEs)



## Requirements

+ numpy

+ matplotlib
  
  

## TREE

|-- odesolve.py              solve functions
|-- plot_result                plot_result
|       |-- error.pdf
|       |-- plot_error.py
|       |-- plot_odesolve.pdf
|       |-- plot_odesolve.py
|-- README.md
|-- result_report.ipynb    result_report
|-- test_odesolve.py        test_odesolve



## Test

` python test_odesolve.py`


