# odesolve.py
#
# Author: <insert name>
# Date:   <insert date>
# Description: <insert description>
#
# You should fill out the code for the functions below so that they pass the
# tests in test_odesolve.py

import math
import numpy as np


def euler(f, x, t, h):
    '''
    f Differential equations that need to be solved
    x inital condition
    t The starting value of the interval
    h stepsize
    return The result of one euler calculation
    '''
    return x + h * f(x, t)


def rk4(f, x, t, h):
    '''
    f Differential equations that need to be solved
    x inital condition
    t The starting value of the interval
    h stepsize
    return The result of one euler calculation
    '''
    k1=f(x,t)
    k2=f(x+0.5*k1*h,t+0.5*h)
    k3=f(x+0.5*k2*h,t+0.5*h)
    k4=f(x+k3*h,t+h)
    return x+h/6*(k1+2*k2+2*k3+k4)


def solveto(f, x1, t1, t2, hmax, method=euler):
    '''
    f Differential equations that need to be solved
    x inital condition
    t1 The starting value of the interval
    t2 The starting value of the interval
    hmax  max stepsize
    method the calculate metho,default euler
    return The result of calculation with the  given function ,it will be a number
    '''

    # Calculates whether the interval length is integral by hmax to
    # determine the step length of the last run when h reaches the critical condition
    lenth = math.ceil((t2-t1)/hmax)
    flag = math.floor((t2-t1)/hmax)

    # Initialize stepsize list and interval list
    h_list =  [hmax for x in range(lenth)]
    t_list =  [t1+hmax*x for x in range(lenth)]

    # Modify the last stepsize
    if flag!=lenth:
        h_list[-1] = t2 - flag*hmax
        t_list[-1] = t2

    # Iterative run
    x_temp = x1
    for t in t_list:
        x_temp=method(f,x_temp,t,h_list[t_list.index(t)])
    return x_temp


def odesolve(f, x0, tvals, h, method=euler):
    '''
    f Differential equations that need to be solved
    x0 inital condition 1Dor2D
    tvals The interval
    h  stepsize
    method the calculate metho,default euler
    return The result of calculation with the given function , it will be a np.array
    '''
    # Calculates whether the interval length is integral by hmax to
    # determine the step length of the last run when h reaches the critical condition
    tvals_list = tvals.tolist()
    t_start = np.min(tvals)
    t_end = np.max(tvals)
    res = []
    lenth = math.ceil((t_end-t_start)/h)
    flag = math.floor((t_end-t_start)/h)
    h_list =  [h for x in range(lenth)]
    t_list =  [t_start+h*x for x in range(1,lenth+1)]

    # Modify the last stepsize
    if flag!=lenth:
        h_list[-1] = t_end - flag*h
        t_list[-1] = t_end

    # whether it is a one-dimensional ordinary differential equation
    if len(x0) ==1:
        x_temp = x0[0]
        res.append(x_temp)
        # Iterative run
        for t in t_list:
            x_temp=method(f,x_temp,t,h_list[t_list.index(t)])
            if t in tvals_list:
                res.append(round(x_temp,8))
    # 2d ODE
    else:
        x_temp = x0
        # Iterative run
        for t in t_list:
            x_temp=method(f,x_temp,t,h_list[t_list.index(t)])
            res.append(x_temp.tolist())
    return np.array(res)
